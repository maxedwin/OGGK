var currentLocation =  $('meta[name="base_url"]').attr('content')+'/';
var table;

var edit  = 0;
/*************BUSQUEDA DE PRODUCTOS POR NOMBRE******************/

$('#btnbusqueda').on('click', function() {
    nombre = $('#busqueda_nombre').val();
    window.location.replace(currentLocation+"list_product?query="+nombre);
});

// Default initialization
$('.wysihtml5').wysihtml5({
    parserRules:  wysihtml5ParserRules,
    stylesheets: ["assets/css/components.css"],
    "image": false,
    "link": false,
    "font-styles": false,
    "emphasis": false
});

$("#marca").select2();
$('#categoria').select2();
$('#motos').select2();



/***************************************************************/

/**********BOTONES DENTRO DE LA TABLA PRODUCTOS ****************/
table = $('#products_table').DataTable( {
    "autoWidth": true,
    "paging": false,
    "searching": false
} );

$('#products_table').on('click', '#detalles', function(event) {
    limpiar();
    event.preventDefault();
    id = $(this).data('product');
    window.location.replace(currentLocation+'single_product?id='+id);
});

$('#products_table').on('click','#status', function(event){
    event.preventDefault();
    idproducto=  $(this).data('idproducto');
    status= $(this).data('status');
    var jqxhr =  $.get(currentLocation+"product_state?id="+idproducto+"&status="+status,function(status){
    }).done(function() {
        swal({
            title: "Cambio el estado!",
            text: "El producto ha cambiado su estado.",
            confirmButtonColor: "#66BB6A",
            type: "success"
        },function(){
            window.location.reload();
        });
    }).fail(function() {
        swal("Error no se ha cambiado el estado del producto", "Intentelo nuevamente luego.", "error");
    })}
);

$('#products_table').on('click','#eliminar' ,function() {
    limpiar();
    idproducto=  $(this).data('idproducto');
    swal({
            title: "Estas seguro?",
            text: "No podras recuperar este producto si lo eliminas!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#EF5350",
            confirmButtonText: "Si, eliminar!",
            cancelButtonText: "No, salir",
            closeOnConfirm: false,
            closeOnCancel: false
        },
        function(isConfirm){
            if (isConfirm) {
                var jqxhr =  $.post(currentLocation+"product_delete",{id:idproducto},function(data,status){

                }).done(function() {
                    swal({
                        title: "Eliminado!",
                        text: "El producto ha sido eliminado.",
                        confirmButtonColor: "#66BB6A",
                        type: "success"
                    },function(){
                        window.location.reload();
                    });
                }).fail(function() {
                    swal("Error al eliminar producto", "Intentelo nuevamente luego.", "error");
                });

            }
            else {
                swal({
                    title: "Cancelado",
                    text: "No se ha eliminado nada :)",
                    confirmButtonColor: "#2196F3",
                    type: "error"
                });
            }
        });
});

$('#products_table').on('click','#editar',function(){
    limpiar();
    edit = 1;

    idproducto=  $(this).data('idproducto');
    barcode= $(this).data('barcode');
    nombre = $(this).data('nombre');
    categoria = $(this).data('categoria');
    precio = $(this).data('precio');
    costo = $(this).data('costo');
    cantidad = $(this).data('cantidad');


    marcas = $(this).data('idmarca');
    barcode = $(this).data('barcode');


    procedencia = $(this).data('procedencia');
    fabricante = $(this).data('fabricante');
    proveedor = $(this).data('proveedor');
    ubicacion = $(this).data('ubicacion');
    descripcion = $(this).data('descripcion');
    status = $(this).data('status');


    var imagenes = $(this).data('imagenes');


    l = 1;
    for(j = 0; j < 4 ; j++){
        if(imagenes['array'][j] !== "undefined"){
            $('#img'+l).attr('src', 'productos/'+imagenes['array'][j]);
            l++;
        }
    }


    $('#idproducto').val(idproducto);
    $('#nombre').val(nombre);
    $('#categoria').val(categoria).change();
    $('#state').val(status).change();
    $('#cantidad').val(cantidad);
    $('#costo').val(costo.toFixed(2));
    $('#precio').val(precio.toFixed(2));
    $('#barcode').val(barcode);

    $('#procedencia').val(procedencia);
    $('#fabricante').val(fabricante);
    $('#proveedor').val(proveedor);
    $('#ubicacion').val(ubicacion);

    $('#descripcion').data("wysihtml5").editor.setValue(descripcion);

    $.get( currentLocation+'get_motos?id='+idproducto, function( data ) {
        $('#motos').val(data);
        $('#motos').select2({
            tags:data,
            maximumInputLength: 10
        });

    });
    $('.titleModal').empty().append(nombre);
    $('#formulario').modal('show');
});




/***************************************************************/

/***********ACCIONES DENTRO DEL MODAL EDITAR Y CREAR ***********/
$('#formulario').on('click','#guardar_cambios',function(){

    idproducto = $('#idproducto').val();
    nombre = $('#nombre').val();
    categoria = $('#categoria').val();
    idmarca = $('#marca').val();
    cantidad = $('#cantidad').val();
    costo = $('#costo').val();
    precio = $('#precio').val();
    descripcion = $('#descripcion').val();
    var motos = $('#motos').val();
    procedencia = $('#procedencia').val();
    fabricante = $('#fabricante').val();
    proveedor = $('#proveedor').val();
    ubicacion = $('#ubicacion').val();
    estado = $('#state').val();
    barcode = $('#barcode').val();

    var img = [];
    for(i = 0; i < 4; i++){
        var src = $('#img'+ String (i+1)).attr('src');
        if( src !== "http://localhost:8000/images/imagen.png" ){
            if( src.length < 20){
                img.push($('#img'+ String (i+1)).attr('src').split("/").pop().split(".")[0]);
            }else{
                img.push($('#img'+ String (i+1)).attr('src'));
            }

        }else{
            img.push("undefined");
        }

    }
    console.log(img);

    var imagenes = img;


    if(validar_datos()===true){
        var arrayPost = {edit:edit,estado:estado,barcode:barcode,idproducto:idproducto, nombre:nombre, categoria:categoria,marca:idmarca,cantidad:cantidad, precio:precio,costo:costo, descripcion:descripcion, motos:motos, procedencia:procedencia,fabricante:fabricante, proveedor:proveedor,ubicacion:ubicacion, imagenes:imagenes};
         var jqxhr =  $.post(currentLocation+"product_store",arrayPost,function(data,status){

        }).done(function() {
            $('#formulario').modal('hide');

            swal({
                    title: "Bien hecho!",
                    text: "Se guardo correctamente",
                    type: "success"
                },
                function(){
                    console.log('ok button');
                    window.location.reload()
                });
            ;
        }).fail(function() {
            swal("Error al guardar", "Intentelo nuevamente luego.", "error");
            });
}

});


var index = 0;

    /**********CARGA DE IMAGENES ********/
    $("#btnfile1").click(function () {
        index = 1;
        $("input#uploadfile1").click();
    });

    $("#btnfile2").click(function () {
        index = 2;
        $("input#uploadfile1").click();
    });

    $("#btnfile3").click(function () {
        index = 3;
        $("input#uploadfile1").click();
    });

    $("#btnfile4").click(function () {
        index = 4;
        $("input#uploadfile1").click();
    });
    /***********************************/
    $("#uploadfile1").change(function(e){
        var nameImage = $(this).val();
        if(nameImage.match(/jpg.*/)||nameImage.match(/jpeg.*/)||nameImage.match(/png.*/)||nameImage.match(/JPG.*/)||nameImage.match(/JPEG.*/)||nameImage.match(/PNG.*/)){
        }else{
            e.preventDefault();
            $('#Inputmensaje').html(' ')
                .append('Este formato no es valido');
        }
        filesLenght = $(this)[0].files.length - 1;

        if (this.files && this.files[filesLenght]) {
            var FR= new FileReader();
            FR.addEventListener("load", function(e) {
                $('#img'+ String(index) ).attr('src', e.target.result);
            });
            FR.readAsDataURL( this.files[filesLenght] );
            console.log(filesLenght);
            $('#Inputmensaje').html(' ')
                .append("File " + this.files[filesLenght].name + " is " + (this.files[filesLenght].size/1024/1024).toPrecision(4) +"{{ $img['array'][0]}}"+ " MB");

        }else{
            $('#Inputmensaje').html(' ')
                .append('No es un archivo');
        }
    });


/***************************************************************/

/*****************NUEVO PRODUCTO********************************/
$('#nuevo_producto').on('click',function(){
    limpiar();
    $('#idproducto').val('');
    $('#nombre').val('');
    $('#categoria').val(0).change();
    $('#cantidad').val('');
    $('#precio').val('');
    $('#costo').val('');
    $('#motos').val(0).change();
    $('#marcas').val(0).change();
    $('.titleModal').empty();
    $('#descripcion').data("wysihtml5").editor.setValue(' ');

    $('#procedencia').val('');
    $('#proveedor').val('');
    $('#fabricante').val('');
    $('#ubicacion').val('');
    $('#barcode').val('');




    $('#img1').attr('src', currentLocation+'images/imagen.png');
    $('#img2').attr('src', currentLocation+'images/imagen.png');
    $('#img3').attr('src', currentLocation+'images/imagen.png');
    $('#img4').attr('src', currentLocation+'images/imagen.png');

    $('#formulario').modal('show');
});

/****************************************************************/

/*****************VALIDAR****************************************/

function validar_datos(){
return true;

}

function limpiar(){
    $('#img1').attr('src', currentLocation+'images/imagen.png');
    $('#img2').attr('src', currentLocation+'images/imagen.png');
    $('#img3').attr('src', currentLocation+'images/imagen.png');
    $('#img4').attr('src', currentLocation+'images/imagen.png');
    $('#nombregroup').removeClass("has-error");
    $('#categoriagroup').removeClass("has-error");
    $('#preciogroup').removeClass("has-error");
    $('#costogroup').removeClass("has-error");
    $('#procedenciagroup').removeClass("has-error");
    $('#fabricantegroup').removeClass("has-error");
    $('#ubicaciongroup').removeClass("has-error");
    $('#proveedorgroup').removeClass("has-error");
}
function strcmp(a, b)
{
    return (a<b?-1:(a>b?1:0));
}

/****************************************************************/
